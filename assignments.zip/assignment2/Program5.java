package core.java.assignment2;

public class Program5 {
	
	public static void display(int n) {
		
		
		int sum=0,rem=0;
		
		
		while(n>0) {
			
			rem=n%10;
			
			sum=rem+sum*10;
			
			n=n/10;
			
			
		}
		
		System.out.println("The reverse of the number is"+""+" "+sum);
		
		
		
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Program5.display(431);

	}

}
