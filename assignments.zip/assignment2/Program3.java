package core.java.assignment2;

public class Program3 {
	
	public static int counter=0;
	
	public static void givennumber(int n) {
		
		for (int i=1;i<=n;i++) {
			
			if(n%i==0) {
				
				counter++;
				
			}
			
			
		}
		
		
		if(counter==2) {
			
			System.out.println("Given number"+""+" "+n+""+" "+"is a Prime number");
		}else {
			
			System.out.println("Given number"+""+" "+n+""+" "+"is not a Prime number");
		}
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Program3.givennumber(13);
	}

}
