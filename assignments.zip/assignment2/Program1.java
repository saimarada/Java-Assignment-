package core.java.assignment2;

public class Program1 {
	
	public static int SumOfArray(int a[]) {
		
		int sum=0;
		
		
		for (int i=0;i<a.length;i++) {
			
			
			sum=sum+a[i];
			
			
			
		}
		return sum;
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[] = {1,23,45,5};

		int arraysize = Program1.SumOfArray(a);
		
		float average = arraysize/a.length;
		
		System.out.println("The average os the given array is"+" "+average);
		
	}

}
