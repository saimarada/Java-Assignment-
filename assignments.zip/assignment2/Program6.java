package core.java.assignment2;

import java.util.Arrays;

public class Program6 {
	
	public static void find(int a[]) {
		
		Arrays.sort(a);
		
		System.out.println("The Dupiates elements are : ");
		
		for(int i=0;i<a.length-1;i++) {
			
			if(a[i]==a[i+1]) {
				
				System.out.println(a[i]+" ");
				
				
			}
			
		}
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[] ={1,3,4,1,4,5,6,6,78,53,1};
		
		Program6.find(a);

	}

}
