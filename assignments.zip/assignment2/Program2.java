package core.java.assignment2;

public class Program2 {
	
	public static void find(int startrange, int endrange) {
		
		System.out.println("The list of odd numbers between"+""+" "+startrange+""+"  "+"and"+""+" "+endrange+""+" "+":");
		
		for (int i=startrange;i<=endrange;i++) {
			
			if(i%2!=0) {
				
				
				System.out.println(i+" ");
				
				
			
				
			}	
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Program2.find(79, 187);

	}

}
