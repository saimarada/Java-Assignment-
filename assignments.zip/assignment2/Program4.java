package core.java.assignment2;

public class Program4 {
	
	public static void Count(int n) {
		
	
		int sum=0,rem=0;
		
		
		while(n>0) {
			
			rem=n%10;
			
			sum=rem+sum;
			
			n=n/10;
			
			
		}
		
		System.out.println("The sum of given numbers is"+""+" "+sum);
		
		
		
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Program4.Count(12111113);
		

	}

}
