package core.java.assignment3;

public class Program6 {
	
	public static void Valid() {
		
		int a=10/0;
		
	}

	public static void main(String[] args) {
		
		Program6.Valid();
		// TODO Auto-generated method stub

	}

}
