package core.java.assignment3;

public class Program4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Converting String to Char Array 
		
		String s="testing";
		
		char[] array =s.toCharArray();
		
		for (char c : array) {
			
			System.out.println("The char array is"+""+" "+c);
			
		}
		
		
		
		//Converting char array to string
		
		String a =String.valueOf(array);
	
		System.out.println("The String is"+""+" "+a);
	}

}
