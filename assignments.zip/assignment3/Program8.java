package core.java.assignment3;

public class Program8 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		try {
		int a=12/0;
		}catch(Exception e){
			
			throw new Exception("error message");

		}
		
	
	}

}
