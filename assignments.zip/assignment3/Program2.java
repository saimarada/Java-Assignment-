package core.java.assignment3;

public class Program2 {
	
	public static void IsPalindrome(String s) {
		
		String rev ="";
		
		for (int i =s.length()-1;i>=0;i--) {
			
			rev = rev+s.charAt(i);
			
		}
		
		
		if(s.equals(rev)) {
			
			System.out.println("Given String"+""+" "+s+""+" "+"is a palindrome");
			
		}else {
			
			System.out.println("Given String"+""+" "+s+""+" "+"is not a palindrome");
		}
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Program2.IsPalindrome("madam");

	}

}
