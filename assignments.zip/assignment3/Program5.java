package core.java.assignment3;

public class Program5 {  
  
    private static final String inputString = "123.33";   
      
    public static void main(String[] args) {  
       try {
                 int a = Integer.parseInt(inputString);  
       }catch(NumberFormatException e) {
    	   
    	   System.out.println("Cannot convert the given string value to Integer");
    	   

    	   
       }
    }
}  