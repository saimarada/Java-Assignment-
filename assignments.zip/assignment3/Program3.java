package core.java.assignment3;

public class Program3 {
	
	public static void ForaWord(String s , String word) {
		
		
		boolean IsPresent=s.contains(word);
		
		if(IsPresent) {
			
			System.out.println("The given string"+""+" "+s+""+" "+"contains"+""+" "+word);
		}
			
		
		
		
	}
	
      public static void ForaWordWithoutDefault(String s , String word) {

    	 boolean IsPresent=false;
		
		String[] words = s.split(" ");
		
		for (String a : words) {
			
			if(a.equals(word)) {
				
				IsPresent=true;
				
				
			}
		}
		
if(IsPresent) {
			
			System.out.println("The given string"+""+" "+s+""+" "+"contains"+""+" "+word);
		}
			
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Program3.ForaWordWithoutDefault("A brown fox ran away fast", "brown");
	}

}
