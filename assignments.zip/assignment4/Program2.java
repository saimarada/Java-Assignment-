	package core.java.assignment4;

import java.util.*;

public class Program2 {
	
	public static void Method(ArrayList<Integer> ar) {
		
		ArrayList<Integer> rev = new ArrayList<Integer>();
		
		
		    for (int i=ar.size()-1;i>=0;i--) {
		    	
		    	rev.add(ar.get(i));
			
		}
		   
		System.out.println("The reverse array list is"+""+" "+rev);    
		    
		    
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Integer> ar = new ArrayList<Integer>();
		
		ar.add(1);ar.add(2);ar.add(3);ar.add(4);ar.add(5);
		
		Program2.Method(ar);
	}

}
