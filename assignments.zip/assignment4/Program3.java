package core.java.assignment4;

import java.util.HashMap;
import java.util.Set;

public class Program3 {
	
	public static void ValidateKeyIsPresent(String key) {
		
		 boolean IsPresent=false;
		
		 HashMap<String,Integer> hm = new HashMap<String,Integer>();
         
         hm.put("Test", 1);
         
         hm.put("Test1", 2);
         
         hm.put("Test3", 3);
         
         
         hm.put("Test4", 4);
         
         
         Set<String> sr = hm.keySet();
         
         
         for (String s : sr) {

         	if(s.equals(key)) {
         		
         		IsPresent=true;
         	}
         	
         }
         
         
         if(IsPresent) {
        	 
        	 System.out.println("The "+""+" "+key+""+" "+"is present in hashmap");
         }else {
        	 
        	 System.out.println("The "+""+" "+key+""+" "+"is not present in hashmap");
         }
         
	}

		

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Program3.ValidateKeyIsPresent("Test1");
           
}
	
}
