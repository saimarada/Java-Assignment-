package core.java.assignment4;

import java.util.*;

public class Program7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<String> ar = new ArrayList<String>();
		
		ar.add("Test");

		ar.add("BTest");
		
		ar.add("CTest");
		
		ar.add("DTest");
		
		ar.add("ATest");
		
		
		System.out.println("The arraylist before sorting"+""+" "+" "+ar);

		
		Collections.sort(ar);
		
		
		System.out.println("The arraylist after sorting"+""+" "+" "+ar);
		
		
	}

}
