	package core.java.assignment4;

import java.util.HashMap;

public class Program1 {
	
	public static void InSttring(String s) {
		
		s=s.toLowerCase();
		
		s=s.replaceAll("\\s", "");
		
		char[] array = s.toCharArray();
		
		HashMap<Character,Integer> hm = new HashMap<Character,Integer>();
		
		
		for (char c : array) {
			
			if(hm.containsKey(c)) {
				
				hm.put(c,hm.get(c)+1);
				
				
			}else {
				
				hm.put(c,1);
				
				
			}
			
			
		}
		
		
		System.out.println("The occurnace of each character is as follows :");
		
		System.out.println(hm);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Program1.InSttring("DevLabs Alliance Training");
	}

}
