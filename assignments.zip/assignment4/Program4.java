package core.java.assignment4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class Program4 {

	
	public static void ToList() {
		
	     ArrayList<String> ar = new ArrayList<String>();
		
		 HashMap<String,Integer> hm = new HashMap<String,Integer>();
        
        hm.put("Test", 1);
        
        hm.put("Test1", 2);
        
        hm.put("Test3", 3);
        
        
        hm.put("Test4", 4);
        
        
        Set<String> sr = hm.keySet();
        
        
        for (String s : sr) {

        	ar.add(s);
        }
        
       
       	 System.out.println("The array list is"+""+" "+ar);
     
        
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Program4.ToList();

	}

}
