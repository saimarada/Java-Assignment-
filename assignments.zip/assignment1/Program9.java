package core.java.assignment1;

public class Program9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Even numbers are:"+" ");
		
		for (int i=0;i<50;i++) {
			
			if(i%2==0) {
				
				System.out.print(i+" ");
			}
			
		}

	}

}
