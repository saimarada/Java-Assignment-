package core.java.assignment1;

public class Program6 {
	
	public static void AreaOfTrainagle(Double Base , Double Height){
		
		 Double area  = (Base*Height)/2;
		
		 System.out.println("Area of Triangle is: " + area); 
		
		
	}

	public static void main(String[] args) {
		
		Program6.AreaOfTrainagle(2.0,3.0);
		// TODO Auto-generated method stub

	}

}
