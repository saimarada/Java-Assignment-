package core.java.assignment1;

public class Program4 {
	
	 public static void Validate(int year) {
		 
		 boolean flag = false;
	        if(year % 400 == 0)
	        {
	            flag = true;
	        }
	        else if (year % 100 == 0)
	        {
	            flag = false;
	        }
	        else if(year % 4 == 0)
	        {
	            flag = true;
	        }
	        else
	        {
	            flag = false;
	        }
	        if(flag)
	        {
	            System.out.println("Year "+year+" is a Leap Year");
	        }
	        else
	        {
	            System.out.println("Year "+year+" is not a Leap Year");
	        }
		 
		 
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Program4.Validate(1001);

	}

}
