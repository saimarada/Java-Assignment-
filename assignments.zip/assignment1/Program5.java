package core.java.assignment1;

public class Program5 {
	
	public static void display(){
		
		int counter=0;
		
		
		
		int firstnumber=2;
		
		while(counter<10) {
			
			int primecount=0;
			
			for(int i=1;i<=firstnumber;i++) {
				
				
				
				   if(firstnumber%i==0) {
					   
					   primecount=primecount+1;
					   
					   
				   }
				   
				 
			}	
			
			  if(primecount==2) {
				   
				   System.out.println("The Prime Number is"+""+firstnumber);
				   
				   counter++;
				   
				   firstnumber=firstnumber+1;
				   
			   }else {
				   
				   firstnumber= firstnumber+1;
			   }
			
		}
		
		
	}

	public static void main(String[] args) {
		
		Program5.display();
		// TODO Auto-generated method stub

	}

}
