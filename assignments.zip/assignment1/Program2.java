package core.java.assignment1;

public class Program2 {
	
	
	//Normal
	public static void print(int range){
		
		int a=0 ,b=1,c=0;
		
		for (int i=0;i<=range;i++) {
			
			System.out.print(a+" ");
			c=a+b;
			
			a=b;
			
			b=c;
			
			
		}
		
		
	}
	
	//Recursion
	
	public static int recursive(int range){
		
		if(range<=1)
			
		return range;
		
		
		return recursive(range-1)+recursive(range-2);
		
	}

	public static void main(String[] args) {
			
		System.out.println("Series using normal method");
	
		Program2.print(10);
		
		System.out.println(" ");
		
		System.out.println("Series using recursion");

		// Print the first N numbers
        for (int i = 0; i <=10; i++) {
        	
            System.out.print(Program2.recursive(i) + " ");
        }
		
	}

}
