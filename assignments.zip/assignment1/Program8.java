package core.java.assignment1;

import java.util.Scanner;

import org.checkerframework.checker.units.qual.Length;

public class Program8 {
	
	public static void ReverseArray(int [] ar) {
		
		for (int i=ar.length-1;i>=0;i--) {
			
			System.out.println(ar[i]);
			
		}
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner s = new Scanner(System.in);
	      System.out.println("Enter the length of the array:");
	      int length = s.nextInt();
	      int [] myArray = new int[length];
	      System.out.println("Enter the elements of the array:");

	      for(int i=0; i<length; i++ ) {
	         myArray[i] = s.nextInt();
	      }
	      
	      Program8.ReverseArray(myArray);
	   }
	

	      
	}
